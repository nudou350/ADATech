export interface Card{
    id: string,
    titulo: string,
    conteudo : string,
    lista : string
}