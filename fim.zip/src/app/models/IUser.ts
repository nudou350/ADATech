export interface User {
    login: string,
    senha: string
}